# SBC OpenLib LaTeX Template

This repository holds the LaTeX class and example article for papers to be submitted for the SBC OpenLib.
